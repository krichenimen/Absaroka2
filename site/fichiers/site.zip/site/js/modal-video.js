$(document).ready(function () {
    /* popup 1 */
    $('.popup-btn1').on('click', function () {
        $('.video-popup1').fadeIn('slow');
        return false;
    });

    $('.popup-bg').on('click', function () {
        $('.video-popup1').slideUp('slow');
        return false;
    });

    $('.close-btn').on('click', function () {
        $('.video-popup1').fadeOut('slow');
        return false;
    });

    /* popup 2 */
    $('.popup-btn2').on('click', function () {
        $('.video-popup2').fadeIn('slow');
        return false;
    });

    $('.popup-bg').on('click', function () {
        $('.video-popup2').slideUp('slow');
        return false;
    });

    $('.close-btn').on('click', function () {
        $('.video-popup2').fadeOut('slow');
        return false;
    });

    /* popup 3 */
    $('.popup-btn3').on('click', function () {
        $('.video-popup3').fadeIn('slow');
        return false;
    });

    $('.popup-bg').on('click', function () {
        $('.video-popup3').slideUp('slow');
        return false;
    });

    $('.close-btn').on('click', function () {
        $('.video-popup3').fadeOut('slow');
        return false;
    });

    /* popup 4 */
    $('.popup-btn4').on('click', function () {
        $('.video-popup4').fadeIn('slow');
        return false;
    });

    $('.popup-bg').on('click', function () {
        $('.video-popup4').slideUp('slow');
        return false;
    });

    $('.close-btn').on('click', function () {
        $('.video-popup4').fadeOut('slow');
        return false;
    });

    /* popup 5 */
    $('.popup-btn5').on('click', function () {
        $('.video-popup5').fadeIn('slow');
        return false;
    });

    $('.popup-bg').on('click', function () {
        $('.video-popup5').slideUp('slow');
        return false;
    });

    $('.close-btn').on('click', function () {
        $('.video-popup5').fadeOut('slow');
        return false;
    });

    /* popup 6 */
    $('.popup-btn6').on('click', function () {
        $('.video-popup6').fadeIn('slow');
        return false;
    });

    $('.popup-bg').on('click', function () {
        $('.video-popup6').slideUp('slow');
        return false;
    });

    $('.close-btn').on('click', function () {
        $('.video-popup6').fadeOut('slow');
        return false;
    });
});
